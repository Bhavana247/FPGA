#include <iostream>
#include "matmul.h"


int main(int argc, char **argv)
{
	mat_a in_mat_a[2][3] = {
	{1,2,3},
	{4,5,6}
	};
	mat_b in_mat_b[3][2] = {
	{1,2},
	{4,5},
	{7,8}
	};
	
	mat_r hw_result[2][2], sw_result[2][2];
	int err_cnt = 0;
	for(int i=0; i<a_rows;i++){
		for(int j=0; i<a_cols;j++)
		{
			sw_result[i][j] = 0;
			for(int k=0;k<b_rows;k++)
				sw_result[i][j] += in_mat_a[i][k] * in_mat_b[k][j];
		}
	}
}